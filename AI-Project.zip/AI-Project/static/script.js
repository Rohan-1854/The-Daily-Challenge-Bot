// function fetchChallenge() {
//   fetch('/daily')
//     .then(response => response.json())
//     .then(data => {
//       document.getElementById('challenge-box').innerText = data.text;
//     })
//     .catch(err => {
//       document.getElementById('challenge-box').innerText = 'Error fetching challenge!';
//     });
// }

// window.onload = fetchChallenge;

let streak = 0;

function startChallenge() {
  const input = document.getElementById("categoryInput").value.toLowerCase();
  const challengeText = document.getElementById("challengeText");
  let challenge = "";

  switch (input) {
    case "java":
      challenge = "💻 Complete 1 Java coding problem today.";
      break;
    case "fitness":
      challenge = "🏋️ Do 30 minutes of exercise or 10k steps.";
      break;
    case "weightloss":
      challenge = "🥗 Stick to your calorie limit and no sugar today!";
      break;
    case "habits":
      challenge = "📘 Read 10 pages of a book or meditate for 15 minutes.";
      break;
    default:
      challenge = "⚠️ Please enter a valid challenge category.";
  }

  if (challenge.includes("⚠️")) return;

  document.getElementById("searchBox").classList.add("hidden");
  document.getElementById("challengeArea").classList.remove("hidden");
  challengeText.innerText = challenge;

  // Save to history
  const li = document.createElement("li");
  li.textContent = input.charAt(0).toUpperCase() + input.slice(1);
  document.getElementById("historyList").appendChild(li);
}

function markCompleted() {
  document.getElementById("reviewSection").classList.remove("hidden");
  document.querySelector(".back-button").classList.remove("hidden");
  document.getElementById("botReview").innerText = "✅ Great job today! Keep it up!";
  updateStreak(1);
}

function nextChallenge() {
  document.getElementById("challengeText").innerText = "📌 Here's your next challenge!";
}

function goBack() {
  document.getElementById("challengeArea").classList.add("hidden");
  document.getElementById("searchBox").classList.remove("hidden");
  document.querySelector(".back-button").classList.add("hidden");
  document.getElementById("reviewSection").classList.add("hidden");
}

function updateStreak(count) {
  streak += count;
  document.getElementById("streak").innerText = streak;
}
